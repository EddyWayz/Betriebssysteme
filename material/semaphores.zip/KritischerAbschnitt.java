import java.util.concurrent.Semaphore;

/**
 * Beispiel 1 f�r Synchronisation mit Semaphoren:
 * Ein bin�res Semaphor realisiert einen kritischen Abschnitt.

 * @author Tobias Lauer
 */
public class KritischerAbschnitt {

	static int kontostand = 100;				// Gemeinsame Variable
	static Semaphore S = new Semaphore(1);		// Semaphore mit S=1 initialisieren
	
	
	public static void main(String[] args) {

		Thread t1 = new Thread() {
			public void run() {
				try {
					System.out.println("Thread 1 m�chte kritischen Abschnitt betreten und Variable ver�ndern");
					S.acquire();
					System.out.println("Thread 1 ist im kritischen Abschnitt");
					kontostand += 40;
					System.out.println("Thread 1 hat Variable ver�ndert: "+kontostand);
					System.out.println("Thread 1 verl�sst kritischen Abschnitt");
					S.release();
				} catch (InterruptedException e) { }
			}
		};
		
		Thread t2 = new Thread() {
			public void run() {
				try {
					System.out.println("Thread 2 m�chte kritischen Abschnitt betreten und Variable ver�ndern");
					S.acquire();
					System.out.println("Thread 2 ist im kritischen Abschnitt");
					kontostand += 90;
					System.out.println("Thread 2 hat Variable ver�ndert auf "+kontostand);
					System.out.println("Thread 2 verl�sst kritischen Abschnitt");
					S.release();
				} catch (InterruptedException e) { }
			}
		};
		
		t1.start();
		t2.start();
		
		
	}
}

