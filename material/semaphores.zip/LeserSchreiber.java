import java.util.concurrent.Semaphore;

/**
 * Beispiel 5 f�r Synchronisation:
 * Leser-Schreiber-Problem
 *  
 * @author Tobias Lauer
 *
 */
public class LeserSchreiber {

	static Semaphore mutex, roomEmpty;
	static int readers;
	static final int NUMBER_OF_THREADS = 3;
	
	public static void main(String[] args) {
		mutex = new Semaphore(1);
		roomEmpty = new Semaphore(1);
		readers = 0;
		
		for (int i=0; i<NUMBER_OF_THREADS; i++) {
			Thread l = new ReaderThread(i);
			Thread s = new WriterThread(i);
			l.start();
			s.start();
		}

	}

	static class WriterThread extends Thread {
		int myID;
		
		public WriterThread(int id) {
			myID = id;
		}
		
		public void run() {
			try {
				System.out.println("Schreiber "+myID+ " wartet auf leeren Raum.");
				roomEmpty.acquire();
				System.out.println("Schreiber "+myID+ " ist im Raum.");
				System.out.println("   Schreiber "+myID+ " schreibt.");
				System.out.println("Schreiber "+myID+ " gibt Raum frei.");
				roomEmpty.release();
			} catch (InterruptedException e) {}
			
		}
	}
	
	static class ReaderThread extends Thread {
		int myID;
		
		public ReaderThread(int id) {
			myID = id;
		}
		
		public void run() {
			try {
				System.out.println("Leser "+myID+ " wartet auf krit. Abschnitt f�r Leser.");
				mutex.acquire();
				System.out.println("Leser "+myID+ " ist im krit. Abschnitt.");
				readers++;
				System.out.println("Leser "+myID+ " erh�ht Leserz�hler auf "+readers);
				if (readers == 1) {
					System.out.println("Leser "+myID+ " war der erste Leser, wartet auf leeren Raum.");
					roomEmpty.acquire();
				} else {
					System.out.println("Leser "+myID+ " ist zus�tzlicher Leser, betritt Raum");
				}
				System.out.println("Leser "+myID+ " ist im Raum, gibt krit. Abschnitt f�r weitere Leser frei.");
				mutex.release();
				
				System.out.println("   Leser "+myID+ " liest...");
				
				System.out.println("Leser "+myID+ " wartet wieder auf krit. Abschnitt f�r Leser.");
				mutex.acquire();
				System.out.println("Leser "+myID+ " ist im krit. Abschnitt.");
				readers--;
				System.out.println("Leser "+myID+ " erniedrigt Leserz�hler auf "+readers);
				System.out.println("Leser "+myID+ " verl�sst Raum.");
				if (readers == 0) {
					System.out.println("Leser "+myID+ " ist der letzte Leser, gibt Raum frei.");
					roomEmpty.release();
				} 
				System.out.println("Leser "+myID+ " gibt krit. Abschnitt f�r weitere Leser frei.");
				mutex.release();
				
			} catch (InterruptedException e) {}
		}
	}
}
