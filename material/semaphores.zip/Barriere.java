import java.util.concurrent.Semaphore;

/**
 * Beispiel 3 f�r Synchronisation mit Sempahoren
 * 2 bin�re Semaphore realisieren eine Barriere 
 * (wie Rendezvouz, aber f�r beliebig viele Threads) 
 * 
 * @author Tobias Lauer
 */
public class Barriere {

	public static Semaphore mutex, barrier;
	static final int NUMBER_OF_THREADS = 5;
	static int count = 0;
	
	public static void main(String[] args) {
		mutex = new Semaphore(1);
		barrier = new Semaphore(0);
		
		for (int i=0; i<NUMBER_OF_THREADS; i++) {
			Thread x = new BarrierThread(i);
			x.start();
		}

	}
	
	static class BarrierThread extends Thread {
		int myID;
		
		public BarrierThread(int ID) {
			myID = ID;
		}
		
		public void run() {
			
			try {
				System.out.println("Thread "+myID+" verarbeitet Code vor Barriere.");
				//System.out.println("Thread "+myID+" will zur Barriere");
				System.out.println("Thread "+myID+" kommt am kritischen Abschnitt an");
				mutex.acquire();
				System.out.println("Thread "+myID+" betritt kritischen Abschnitt");
				count++;
				System.out.println("   Thread "+myID+" ver�ndert Variable auf "+count);
				System.out.println("Thread "+myID+" gibt kritischen Abschnitt frei.");
				mutex.release();
				if (count == NUMBER_OF_THREADS) {
					System.out.println("Thread "+myID+" gibt Barriere frei.");
					barrier.release();
				}
				System.out.println("Thread "+myID+" wartet an der Barriere");
				barrier.acquire();
				System.out.println("Thread "+myID+" geht durch Drehkreuz");
				barrier.release();
				System.out.println("Thread "+myID+" verarbeitet Code nach Barriere");
				
			} catch (InterruptedException e) {}
			
		}
		
	}

}

