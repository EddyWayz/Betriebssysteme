import java.util.concurrent.Semaphore;


/**
 * Beispiel 2 f�r Synchronisation mit Sempahoren
 * Zwei Threads warten aufeinander, bevor sie beide weitermachen.
 *  
 * @author Tobias Lauer
 *
 */
public class Rendezvouz {

	public static void main(String[] args) {
		Semaphore S1 = new Semaphore(0);
		Semaphore S2 = new Semaphore(0);
		
		Thread t1 = new RendezvouzThread(1, S1, S2);
		Thread t2 = new RendezvouzThread(2, S2, S1);
		
		t1.start();
		t2.start();

	}

}

class RendezvouzThread extends Thread {
	int myID;
	Semaphore toWait, toSignal;
	
	public RendezvouzThread(int id, Semaphore toWait, Semaphore toSignal) {
		myID = id;
		this.toWait = toWait;
		this.toSignal = toSignal;
	}
	
	public void run() {
		if (myID == 1) {
			try {
				Thread.sleep(200);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println("Thread "+myID+": Code-Teil vor der Barriere wird abgearbeitet.");
		
		try {
			System.out.println("Thread "+myID+" gibt Semaphore frei.");
			toSignal.release();	// 1. Teil erledigt: signalisieren
			System.out.println("Thread "+myID+" wartet auf anderen Thread.");
			toWait.acquire();	// Auf anderen Thread warten
		} catch (InterruptedException e) {
			e.printStackTrace();
		}   
		
		System.out.println("Thread "+myID+": Code-Teil nach der Barriere wird abgearbeitet.");
		
		
		
	}
}
