import java.util.concurrent.Semaphore;

/**
 * Beispiel 2 f�r Synchronisation mit Sempahoren
 * Zwei Threads warten aufeinander, bevor sie beide weitermachen.
 *  
 * @author Tobias Lauer
 *
 */
public class Rendezvouz {

	public static void main(String[] args) {
		Semaphore S1 = new Semaphore(0);
		Semaphore S2 = new Semaphore(0);
		
		Thread t1 = new RendezvouzThread(1, S1, S2);
		Thread t2 = new RendezvouzThread(2, S2, S1);
		
		t1.start();
		t2.start();

	}

}

class RendezvouzThread extends Thread {
	int myID;
	Semaphore areYouDone, iAmDone;
	
	public RendezvouzThread(int id, Semaphore areYouDone, Semaphore iAmDone) {
		myID = id;
		this.areYouDone = areYouDone;
		this.iAmDone = iAmDone;
	}
	
	public void run() {
		System.out.println("Thread "+myID+": Code-Teil vor der Barriere wird abgearbeitet.");
		
		try {
			System.out.println("Thread "+myID+" gibt Semaphor frei.");
			iAmDone.release();	// 1. Teil erledigt: signalisieren
			System.out.println("Thread "+myID+" wartet auf anderen Thread.");
			areYouDone.acquire();	// Auf anderen Thread warten
		} catch (InterruptedException e) {
			e.printStackTrace();
		}   
		
		System.out.println("Thread "+myID+": Code-Teil nach der Barriere wird abgearbeitet.");
		
	}
}
