import java.util.concurrent.Semaphore;

/**
 * Beispiel 5 f�r Synchronisation:
 * Leser-Schreiber-Problem
 *  
 * @author Tobias Lauer
 *
 */
public class LeserSchreiber {

	static Semaphore mutex, roomEmpty;
	static int readers;
	static final int NUMBER_OF_READERS = 3;
	static final int NUMBER_OF_WRITERS = 2;
	
	static boolean verbose = true;
	
	public static void main(String[] args) {
		mutex     = new Semaphore(1);
		roomEmpty = new Semaphore(1);
		readers   = 0;
		
		for (int i=0; i<NUMBER_OF_READERS; i++) {
			Thread l = new ReaderThread(i);
			
			l.start();
		}
		for (int i=0; i<NUMBER_OF_WRITERS; i++) {
			Thread s = new WriterThread(i);
			s.start();
		}

	}

	static class WriterThread extends Thread {
		int myID;
		
		public WriterThread(int id) {
			myID = id;
		}
		
		public void run() {
			try {
				Thread.sleep((int)(Math.random()*9));
				if (verbose) System.out.println("Writer "+myID+ " wants to write, waiting for empty room.");
				// Wait for "empty room"
				roomEmpty.acquire();
				if (verbose) System.out.println("Writer "+myID+ " has entered the room.");
				// Write
				System.out.println("   Writer "+myID+ " is writing... finished.");
				
				System.out.println("   Writer "+myID+ " is writing... finished.");
				// Leave room
				roomEmpty.release();
				if (verbose) System.out.println("Writer "+myID+ " has left the room.");
			} catch (InterruptedException e) {}
			
		}
	}
	
	static class ReaderThread extends Thread {
		int myID;
		
		public ReaderThread(int id) {
			myID = id;
		}
		
		public void run() {
			try {
				Thread.sleep((int)(Math.random()*10));
				if (verbose) System.out.println("Reader "+myID+ " wants to read, waiting to increment reader count.");
				mutex.acquire();
				if (verbose) System.out.println("Reader "+myID+ " has entered critical section.");
				readers++;
				if (verbose) System.out.println("Reader "+myID+ " increments reader count to "+readers);
				if (readers == 1) {
					System.out.println("Reader "+myID+ " is the first reader, waiting for empty room.");
					roomEmpty.acquire();
					System.out.println("Reader "+myID+ " has opened room for readers.");
				} else {
					if (verbose) System.out.println("Other readers are present, so reader "+myID+ " can access room directly.");
				}
				if (verbose) System.out.println("Reader "+myID+ " has entered room and releases critical section for reader count.");
				mutex.release();
				
				System.out.println("   Reader "+myID+ " is reading... ");
				Thread.sleep(2);
				System.out.println("   Reader "+myID+ " has finished reading.");
				if (verbose) System.out.println("Reader "+myID+ " is waiting to decrement reader count.");
				mutex.acquire();
				if (verbose) System.out.println("Reader "+myID+ " has entered critical secion.");
				readers--;
				if (verbose) System.out.println("Reader "+myID+ " decrements reader count to "+readers);
				if (verbose) System.out.println("Reader "+myID+ " is leaving the room.");
				if (readers == 0) {
					System.out.println("Reader "+myID+ " was the last reader and closes the room.");
					roomEmpty.release();
				} 
				if (verbose) System.out.println("Reader "+myID+ " releases the critical section for reader count.");
				mutex.release();
				
			} catch (InterruptedException e) {}
		}
	}
}
