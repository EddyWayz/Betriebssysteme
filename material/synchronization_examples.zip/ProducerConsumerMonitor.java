import java.util.LinkedList;
import java.util.Queue;

/**
 * This class demonstrates the use of an object monitor 
 * for synchronization.
 *  
 * @author Tobias Lauer
 *
 */
public class ProducerConsumerMonitor {

	static Queue<String> queue;
	static int bufferSize = 1;
	static final int NUMBER_OF_THREADS = 2;
	
	
	public static void main(String[] args) {
		ProducerConsumerMonitor buffer = new ProducerConsumerMonitor();
		queue = new LinkedList<String>();

		for (int i=0; i<NUMBER_OF_THREADS; i++) {
			Thread p = new ProducerThread(i, buffer);
			Thread c = new ConsumerThread(i, buffer);
			c.start();
			p.start();
		}

	}

	/*
	 * Inner class for Producer Threads
	 */
	static class ProducerThread extends Thread {
		int myID;
		ProducerConsumerMonitor buffer;
		int objectNo;
		
		public ProducerThread(int id, ProducerConsumerMonitor buffer) {
			myID = id;
			this.buffer = buffer;
			objectNo = 0;
		}
		
		public void run() {
			objectNo++;
			String o = new String(myID+"-"+objectNo);
			System.out.println("Producer "+myID+" hat Objekt "+o+" erzeugt.");
			System.out.println("Producer "+myID+" wartet auf Monitor.");
			try {
				buffer.addToBuffer(o, myID);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("Producer "+myID+" hat Monitor freigegeben.");
		}
		
	}
	
	public synchronized void addToBuffer(String o, int myID) throws InterruptedException {
		System.out.println("   Producer "+myID+" hat den Monitor.");
		while (queue.size() == bufferSize) {
			System.out.println("   Producer "+myID+" wartet auf freien Platz (Monitor wird freigegeben!).");
			wait();
		}
		queue.add(o);
		System.out.println("   Producer "+myID+" hat Objekt "+o+" hinzugef�gt");
		System.out.println("   Producer "+myID+" benachrichtigt wartende Consumer Threads.");
		notifyAll();
	}

	/*
	 * Inner class for Consumer Threads
	 */
	static class ConsumerThread extends Thread {
		int myID;
		ProducerConsumerMonitor buffer;
		
		public ConsumerThread(int id, ProducerConsumerMonitor buffer) {
			myID = id;
			this.buffer = buffer;
		}
		
		public void run() {
			try {
				System.out.println("Consumer "+myID+" wartet auf Monitor.");
				
				String s = buffer.getFromBuffer(myID);
				System.out.println("Consumer "+myID+" hat Monitor freigegeben.");
				System.out.println("Consumer "+myID+" verarbeitet Objekt " +s);
			} catch (InterruptedException e) {}	
		}
	}
	
	public synchronized String getFromBuffer(int myID) throws InterruptedException {
		System.out.println("   Consumer "+myID+" hat den Monitor");
		while (queue.isEmpty()) {
			System.out.println("   Consumer "+myID+" wartet auf Objekte (Monitor wird freigegeben!).");
			wait();
		}
		System.out.println("   Consumer "+myID+": Objekt vorhanden.");
		String s = queue.remove();
		System.out.println("   Consumer "+myID+" holt Objekt "+s);
		System.out.println("   Consumer "+myID+" benachrichtigt wartende Producer Threads.");
		notifyAll();
		return s;
	}
}
