import java.util.LinkedList;
import java.util.Queue;
import java.util.concurrent.Semaphore;

/**
 * Beispiel 4 f�r Synchronisation mit Sempahoren
 * Erzeuger-Verbraucher-Problem:
 * 
 * @author Tobias Lauer
 */
public class ProducerConsumer {
	
	static Queue<String> buffer;
	static Semaphore mutex, items, emptySpaces;
	static final int NUMBER_OF_THREADS = 4;
	
	
	public static void main(String[] args) {
		buffer      = new LinkedList<String>();
		mutex       = new Semaphore(1);
		items       = new Semaphore(0);
		emptySpaces = new Semaphore(1);		// buffer size

		for (int i=0; i<NUMBER_OF_THREADS; i++) {
			Thread p = new ProducerThread(i);
			Thread c = new ConsumerThread(i);
			c.start();
			p.start();
		}

	}

	/**
	 * The code for Producer threads.
	 * 
	 * @author Tobias Lauer
	 */
	static class ProducerThread extends Thread {
		int myID;
		int objectNo;
		
		public ProducerThread(int id) {
			myID = id;
			objectNo = 0;
		}
		
		public void run() {
			try {
				objectNo++;
				String o = new String(myID+"-"+objectNo);
				System.out.println("Thread P"+myID+" hat Objekt "+o+" erzeugt.");
				System.out.println("Thread P"+myID+" wartet auf freien Platz im Puffer.");
				emptySpaces.acquire();
				System.out.println("Thread P"+myID+" hat freien Platz im Puffer.");
				System.out.println("Thread P"+myID+" wartet auf kritischen Abschnitt, um Objekt einzuf�gen.");
				mutex.acquire();	// entspricht Wait(mutex)
					System.out.println("   Thread P"+myID+" ist im kritischen Abschnitt.");
					buffer.add(o);
					System.out.println("   Thread P"+myID+" f�gt Objekt "+o+" hinzu.");
					System.out.println("   Thread P"+myID+" z�hlt Objekt-Semaphor hoch.");
					items.release();	// entspricht Signal(items)
					System.out.println("   Thread P"+myID+" gibt kritischen Abschnitt frei.");
				mutex.release();	// entspricht Signal(mutex)
			} catch (InterruptedException e) {}
			
		}
	}
	
	/**
	 * The code for Consumer threads.
	 * 
	 * @author Tobias Lauer
	 */
	static class ConsumerThread extends Thread {
		int myID;
		
		public ConsumerThread(int id) {
			myID = id;
		}
		
		public void run() {
			try {
				System.out.println("Thread C"+myID+" wartet auf Objekte.");
				items.acquire();
				System.out.println("Thread C"+myID+": Objekt vorhanden.");
				System.out.println("Thread C"+myID+" wartet auf kritischen Abschnitt, um Objekt zu holen.");
				mutex.acquire();
					System.out.println("   Thread C"+myID+" ist im kritischen Abschnitt.");
					String s = buffer.remove();
					System.out.println("   Thread C"+myID+" holt Objekt "+s+".");
					System.out.println("   Thread C"+myID+" z�hlt Semaphor f�r freie Pl�tze hoch.");
					emptySpaces.release();
					System.out.println("   Thread C"+myID+" gibt kritischen Abschnitt frei");
				mutex.release();
				
				System.out.println("Thread C"+myID+" verarbeitet Objekt");
			} catch (InterruptedException e) {}
			
		}
	}
}

