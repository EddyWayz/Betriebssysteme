import java.util.concurrent.Semaphore;

/**
 * Beispiel 3 f�r Synchronisation mit Sempahoren
 * 2 bin�re Semaphore realisieren eine Barriere 
 * (wie Rendezvouz, aber f�r beliebig viele Threads) 
 * 
 * @author Tobias Lauer
 */
public class Barriere {

	static final int NUMBER_OF_THREADS = 3;
	public static Semaphore mutex, barrier;
	static int count = 0;
	
	public static void main(String[] args) {
		mutex = new Semaphore(1);	// Semaphor f�r krit. Abschnitt, anfangs offen
		barrier = new Semaphore(0);	// Semaphor f�r Barriere, anfangs geschlossen

		// Erzeuge und starte die Threads
		for (int i=0; i<NUMBER_OF_THREADS; i++) {
			Thread x = new BarrierThread(i);
			x.start();
		}

	}
	
	/**
	 * Innere Klasse f�r Threads
	 */
	static class BarrierThread extends Thread {
		int myID;	// Jeder Thread hat eine Nummer (f�r Ausgabe)
		
		public BarrierThread(int ID) {
			myID = ID;
		}
		
		public void run() {
			
			try {
				// Teil 1 Start
				System.out.println("Thread "+myID+": Code-Teil vor der Barriere wird abgearbeitet."); //verarbeitet Code vor Barriere.");
				// Teil 1 fertig
			
				//System.out.println("Thread "+myID+" will Z�hler erh�hen, ben�tigt kritischen Abschnitt.");
				mutex.acquire();
				//System.out.println("Thread "+myID+" ist im kritischen Abschnitt");
				count++;
				//System.out.print("   Thread "+myID+" erh�ht Z�hler auf "+count);
				//System.out.println(" und gibt kritischen Abschnitt frei.");
				mutex.release();
				if (count == NUMBER_OF_THREADS) {
					//System.out.println("\nAlle Threads haben Z�hler erh�ht. Thread "+myID+" gibt Barriere frei.\n");
					barrier.release();
				}
				//System.out.println("Thread "+myID+" kommt an Barriere an.");
				barrier.acquire();
				//System.out.println("Thread "+myID+" geht durch Drehkreuz.");
				barrier.release();
				
				// Teil 2 Start
				System.out.println("Thread "+myID+": Code-Teil nach der Barriere wird abgearbeitet."); //verarbeitet Code nach Barriere");
				// Teil 2 Ende
			} catch (InterruptedException e) {}
			
		}
		
	}

}

